const materials = [
    {"description": "Mouse", "reel": 1234},
    {"description": "Bag", "reel": 8345},
    {"description": "Phone CaSE", "reel": 331199},
    {"description": "Monitor", "reel": 997718},
    {"description": "CabLe c", "reel": 391829}
];

const checkMaterial = async () => {
    const article = document.getElementById('article').value.trim();
    const reelInput = document.getElementById('reel').value.trim();

    if (!article || !reelInput) {
        alert('Por favor, completa ambos campos.');
        return;
    }

    const material = materials.find(m => m.reel == reelInput);

    if (material) {
        if (material.description.toLowerCase() === article.toLowerCase()) {
            document.getElementById('message').innerText = 'Este material es el correcto.';
        } else {
            document.getElementById('message').innerText = 'Este material es incorrecto.';
        }
    } else {
        document.getElementById('message').innerText = 'Material no encontrado.';
    }
};
