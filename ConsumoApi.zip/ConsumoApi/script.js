async function searchMovie() {
    const movieTitle = document.getElementById('movieTitle').value;
    const apiKey = '7e616184';
    const apiUrl = `http://www.omdbapi.com/?apikey=${apiKey}&t=${movieTitle}`;

    const response = await fetch(apiUrl);
    const data = await response.json();

    if (data.Response === "True") {
        document.getElementById('title').innerText = data.Title;
        document.getElementById('description').innerText = data.Plot;
        document.getElementById('poster').src = data.Poster;
    } else {
        document.getElementById('title').innerText = 'Película no encontrada';
        document.getElementById('description').innerText = '';
        document.getElementById('poster').src = '';
    }
}
